import alo

def printDois():
    '''Imprimir o resultados de alo.dois()'''
    print(alo.dois())

def main():
    '''Função principal'''
    printDois()

if __name__ == "__main__":
    main()
