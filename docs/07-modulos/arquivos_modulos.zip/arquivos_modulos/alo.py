def dois():
 '''Função que retorna 2'''
 return 2

class Alo:
 '''Classe ainda não implementada'''
 pass

